package com.dbs.springmvcapp.repository;

public interface EmployeeDAO {
}